--Question 1
--IF EXISTS (SELECT * FROM sysobjects WHERE name='warningClientInsertion')
--	DROP TRIGGER warningClientInsertion;
--GO

--CREATE TRIGGER warningClientInsertion
--ON CLIENT
--AFTER INSERT
--AS
--SET  NOCOUNT ON
--BEGIN
--	SELECT 'Un ou plusieurs nouveau(x) client(s) a/ont �t� ins�r�(s) dans la table CLIENT';
--END
--GO


--Question 2
--IF EXISTS (SELECT * FROM sysobjects WHERE name='infoClientInsertion')
--	DROP TRIGGER infoClientInsertion;
--GO

--CREATE TRIGGER infoClientInsertion
--ON CLIENT
--AFTER INSERT
--AS
--SET NOCOUNT ON
--BEGIN
--	SELECT * FROM inserted;
--	SELECT * FROM deleted;
--END
--GO


--Question 3
--IF EXISTS (SELECT * FROM sysobjects WHERE name='countClientInsertion')
--	DROP TRIGGER countClientInsertion;
--GO

--CREATE TRIGGER countClientInsertion
--ON CLIENT
--AFTER INSERT
--AS
--SET NOCOUNT ON
--BEGIN
--	SELECT CONCAT(COUNT(Cl_Nom), ', nouveau(x) client(s) ins�r�(s) dans la table CLIENT') FROM INSERTED
--END
--GO


--Question 4
--IF EXISTS (SELECT * FROM sysobjects WHERE name='infoClientUpdate')
--	DROP TRIGGER infoClientUpdate;
--GO
--CREATE TRIGGER infoClientUpdate
--ON CLIENT
--AFTER UPDATE
--AS
--SET NOCOUNT ON
--BEGIN
--	SELECT * FROM inserted;
--	SELECT * FROM deleted;
--END
--GO


--Question 5
--IF EXISTS (SELECT * FROM sysobjects WHERE name='nullClientDelete')
--	DROP TRIGGER nullClientDelete;
--GO

--CREATE TRIGGER nullClientDelete
--ON CLIENT
--INSTEAD OF DELETE
--AS
--SET NOCOUNT ON
--BEGIN
--	SELECT 'Commande Delete Inactive';
--END
--GO



--Question 6 --Encours
IF EXISTS (SELECT * FROM sysobjects WHERE name='tooMuchClientInsertion')
	DROP TRIGGER tooMuchClientInsertion;
GO

CREATE TRIGGER tooMuchClientInsertion
ON CLIENT
AFTER INSERT
AS
SET NOCOUNT ON
BEGIN
	IF (SELECT COUNT(*) FROM INSERTED)>=10
	BEGIN
		ROLLBACK TRANSACTION;
		SELECT 'La commande a �t� interrompue';
	END
END 
GO
	