--Question 1
--INSERT INTO CLIENT VALUES ('EuroMoto','Chateauroux',22,'Filtre',940,'2016-02-22');

--IF EXISTS (SELECT * FROM sysobjects WHERE name='warningClientInsertion')
--	DROP TRIGGER warningClientInsertion;
--GO

--Question 2
--INSERT INTO CLIENT VALUES ('Car Fur','Angers',18,'Piston',940,'2015-08-01'),
--	('FranceV�lo','La roche sur yon',9,'Tuyau',1210,'2017-04-17'),
--		('Le clair automobile','Glomel',38,'Valve',710,'2015-11-24');

--IF EXISTS (SELECT * FROM sysobjects WHERE name='warningClientInsertion')
--	DROP TRIGGER warningClientInsertion;
--GO

--Question 3
--INSERT INTO CLIENT VALUES ('EuroMoto','Chateauroux',22,'Filtre',940,'2016-02-22'),
--	('FranceV�lo','La roche sur yon',9,'Tuyau',1210,'2017-04-17'),
--		('Le clair automobile','Glomel',38,'Valve',710,'2015-11-24');

--IF EXISTS (SELECT * FROM sysobjects WHERE name='countClientInsertion')
--	DROP TRIGGER countClientInsertion;
--GO

--Question 4
--UPDATE CLIENT SET Cl_En_cours*=2 WHERE Cl_Nom LIKE 'L%';
--SELECT * FROM CLIENT;
--GO

--IF EXISTS (SELECT * FROM sysobjects WHERE name='infoClientUpdate')
--	DROP TRIGGER infoClientUpdate;
--GO

--Question 5
--DELETE FROM CLIENT WHERE Cl_Nom='Best CAR Buy';
--SELECT * FROM CLIENT;

--IF EXISTS (SELECT * FROM sysobjects WHERE name='nullClientDelete')
--	DROP TRIGGER nullClientDelete;
--GO

--Question 6 --EnCours

IF EXISTS (SELECT * FROM sysobjects WHERE name='tooMuchClientInsertion')
	DROP TRIGGER tooMuchClientInsertion;
GO