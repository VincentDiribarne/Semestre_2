--Question 1
--Select * FROM info_client;

--Question 3
--Select * from info_client

--Question 4
--Select * from info_client

--Question 6
--Select * from info_client_Lyon

--Question 8
--Select * from info_salle

--Question 10
--Select * from info_salle_paris

--Question 12
--Select * from info_salle

--Question 17
--Select * from client_spectacle

--Question 18
--Select * from spectacle_info

--Question 23
--Select * from spectacle_info order by Nom_Spectacle, date_spectacle