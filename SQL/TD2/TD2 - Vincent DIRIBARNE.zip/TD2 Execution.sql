--Exercice 1

--Question 1

--EXECUTE clientLPL;
--GO


--Question 2

--EXECUTE activiteLPL;
--GO


--Question 3 (version 1)

--EXECUTE clientPremium 7000.0;
--GO


--Question 3 (version 2)

--EXECUTE clientPremium2 7000.0;
--GO


--Question 4