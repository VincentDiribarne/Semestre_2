--Exercice 1

--Question 1

--IF EXISTS (SELECT * FROM sysobjects WHERE name='clientLPL')
--DROP PROCEDURE clientLPL;
--GO

--CREATE PROCEDURE clientLPL 
--AS
--SET NOCOUNT ON
--BEGIN
--	DECLARE @Nom VARCHAR(100), @Prenom VARCHAR(100), @solde INT;
--	DECLARE AffInfoClient CURSOR LOCAL FOR SELECT CLIENT.nom, CLIENT.Pr�nom, CLIENT.solde FROM CLIENT;	
--	OPEN AffInfoClient;
--	FETCH AffInfoClient INTO @Nom, @Prenom, @solde;
--	WHILE @@FETCH_STATUS=0
--	BEGIN
--		SELECT @Nom, @Prenom, @solde;
--		FETCH AffInfoClient INTO @Nom, @Prenom, @solde;
--	END
--	CLOSE AffInfoClient
--	DEALLOCATE AffInfoClient
--END
--GO

--Question 2

--IF EXISTS (SELECT * FROM sysobjects WHERE name='activiteLPL')
--DROP PROCEDURE activiteLPL;
--GO

--CREATE PROCEDURE activiteLPL 
--AS
--SET NOCOUNT ON
--BEGIN
--	DECLARE @Nom VARCHAR(100), @Libell� VARCHAR(100), @prix INT;
--	DECLARE @temp VARCHAR(100), @temp2 VARCHAR(100);
--	DECLARE AffInfoActivites CURSOR LOCAL FOR SELECT ACTIVITES.Nom_station, ACTIVITES.libell�, ACTIVITES.prix FROM ACTIVITES ORDER BY ACTIVITES.Nom_station;	
--	OPEN AffInfoActivites;
--	FETCH AffInfoActivites INTO @Nom, @Libell�, @prix;
--	SELECT @Nom, @Libell�, @prix;
--	SET @temp=@Nom;
--	WHILE @@FETCH_STATUS=0
--	BEGIN
--	FETCH AffInfoActivites INTO @Nom, @Libell�, @prix;
--		IF @temp<>@nom
--			BEGIN
--			SELECT @Nom, @Libell�, @prix;
--			END
--	SET @temp=@nom;
--	END
--	CLOSE AffInfoActivites
--	DEALLOCATE AffInfoActivites
--END
--GO


--Question 3

--IF EXISTS (SELECT * FROM sysobjects WHERE name='clientPremium')
--DROP PROCEDURE clientPremium;
--GO

--CREATE PROCEDURE clientPremium 
--@solde_min FLOAT
--AS
--SET NOCOUNT ON
--BEGIN
--	DECLARE @clientPremium TABLE (
--		Nom VARCHAR(100),
--		Prenom VARCHAR(100),
--		Solde INT
--	);
	
--	DECLARE @Nom VARCHAR(100), @prenom VARCHAR(100), @prix INT;
--	DECLARE AffInfoActivites CURSOR LOCAL FOR SELECT CLIENT.nom, CLIENT.Pr�nom, CLIENT.solde FROM CLIENT;
--	OPEN AffInfoActivites;
--	FETCH AffInfoActivites INTO @Nom, @prenom, @prix;
--	WHILE @@FETCH_STATUS=0
--	BEGIN
--	IF @prix >= @solde_min
--		INSERT INTO @clientPremium (Nom, Prenom, Solde) VALUES (@Nom, @prenom, @prix);
--		FETCH AffInfoActivites INTO @Nom, @prenom, @prix;
--	END
--	CLOSE AffInfoActivites
--	DEALLOCATE AffInfoActivites
--	SELECT * FROM @clientPremium;
--END
--GO


--Question 3 (version 2)

--IF EXISTS (SELECT * FROM sysobjects WHERE name='clientPremium2')
--DROP PROCEDURE clientPremium2;
--GO

--CREATE PROCEDURE clientPremium2 
--@solde_min FLOAT
--AS
--SET NOCOUNT ON
--BEGIN
--	DECLARE @clientPremium TABLE (
--		Nom VARCHAR(100),
--		Prenom VARCHAR(100),
--		Solde INT
--	);
--	INSERT INTO @clientPremium SELECT nom, pr�nom, solde FROM CLIENT WHERE solde >= @solde_min	
--	SELECT * FROM @clientPremium;
--END
--GO

--Question 4 